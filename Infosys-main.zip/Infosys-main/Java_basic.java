import java.util.*;

class SignUp{
  public void login(ArrayList<String> Id, ArrayList<String> Password){
    Scanner sc = new Scanner(System.in);
    System.out.print("Enter your email: ");
    String id =sc.nextLine();

    System.out.print("Enter Password: ");
    String pass =sc.nextLine();

    System.out.println();

    boolean found = false;

    for(int i = 0; i< Id.size(); i++){

      if(id.equals(Id.get(i) && pass.equals(Password.get(i))){
        System.out.println("WElcome");
        found =true;
        break;

      }

    }

    if(!found){
      System.out.println("Enter valid Email Id or Password. Try Again");
    }
    

  }

  public void signUp(ArrayList<> add kr dena ){
    Display-- account create

    while loop(ch == Yes){

      Input and add in arraylist
    }

    

}


public class Project{

  public static void main(String[] arg){
   ArrayList<String> id = new ArrayList<>();
    similary create pass list

  add temp data for id and pass


  make an object for the class 
  invoke the class methods
  }
}
